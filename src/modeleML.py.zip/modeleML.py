import numpy as np
import tensorflow as tf
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
import matplotlib.pyplot as plt


read_file = open('/Users/jeannelonglune/Desktop/memoire/pyCabaret/src/storage_MLdata/ML1000.csv', 'r')

data_list = []
for line in read_file:
    data = line.split(', ')
    data_list.append([[float(data[0]), float(data[1]), float(data[2])], [float(data[3])]])
            
print(data_list)

# Modif format datalist
x = np.array([item[0] for item in data_list])  # Entrées : altitude, Mach, taille du déchet
y = np.array([item[1] for item in data_list])  # Sortie : flux de chaleur

#print('x check ', x)
#print('y check ', y)

# entraînement (70%)  validation (30%)
X_train, X_val, y_train, y_val = train_test_split(x, y, test_size=0.3, random_state=42) 
#spécifier une graine (seed) pour le générateur de nombres aléatoires. L'utilisation d'une graine garantit que la séparation des donnée

# modèle
model = tf.keras.Sequential([
    tf.keras.layers.Dense(64, activation='relu', input_shape=(3,)),  # 3 features en entrée
    tf.keras.layers.Dense(1)  # 1 output
])

# Build a simple linear regression model
#model = tf.keras.Sequential()
#model.add(tf.keras.layers.Dense(1, input_dim=3))

#history = model.fit(X_train, y_train, epochs=10, validation_data=(X_val, y_val), validation_split=0.3)

# Normaliser 
from sklearn.preprocessing import StandardScaler

scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_val_scaled = scaler.transform(X_val)

# Compilation
model.compile(optimizer='adam', loss='mean_squared_error')

#print('x train', X_train)
#print('y_train', y_train)

#print('x_val ', X_val)
#print('y_val', y_val)

# Entraînement
history = model.fit(X_train, y_train, epochs=10, batch_size=32, validation_data=(X_val, y_val))

# Évaluation
predictions = model.predict(X_val)
mse = mean_squared_error(y_val, predictions)
print(f'Mean Squared Error on Validation Set: {mse}')

# Évaluation des performances 
predictions = model.predict(X_val)
mse = mean_squared_error(y_val, predictions)
print(f'Mean Squared Error on Validation Set: {mse}')

# test
new_data = np.array([[0.1, 50, 18]])
prediction = model.predict(new_data)
#prediction = modele(60, 23, 0.5)
print(f'Prédiction pour de nouvelles données : {prediction}')
